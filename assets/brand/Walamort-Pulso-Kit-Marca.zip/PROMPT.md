# Preparación del emblema

Herramienta integrada image_gen, edición con transparencia de 04-pulso.png. Solicitud: aislar únicamente el emblema circular aprobado, conservar disco burdeos con surcos, borde naranja cobrizo y W sonora, vista frontal, sin texto ni objetos adicionales. Posteriormente se generaron tamaños optimizados para web y una reducción SVG plana para favicon.
