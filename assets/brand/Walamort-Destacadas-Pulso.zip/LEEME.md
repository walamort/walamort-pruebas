# Destacadas Walamort · Pulso

Ocho portadas sin texto para poder usarlas en español, inglés o portugués. Subir cada imagen como portada de la historia destacada y centrar el círculo en el selector de recorte. El nombre de la categoría se escribe en la interfaz de la red social, debajo de la portada.

Categorías: Cuerdas, Producción, Kalimba, Percusión, Vientos, Academy, Museo y Métodos.

Estilo: burdeos oscuro, cobre naranja, detalles crema y volumen realista. Imágenes creadas con la herramienta integrada image_gen tomando como referencia visual la identidad Pulso aprobada.
